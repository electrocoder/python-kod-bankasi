
import pygame

def mp3():
    pygame.mixer.init(22050, -16, 2, 3072)
    pygame.mixer.music.load('John Manno.mp3')
    pygame.mixer.music.play(50, 0.0)

