#! /usr/bin/env python
#-*- coding: utf8 -*-
#Projenin Adı : sinif-1-el-yazısı-egitim-programı
#Tarih : 21-11-2011
#Yazar : electrocoder
#İletişim : electrocoder@gmail.com
#Web : http://pythontr.org
#Python Ver. : 2.7
#Guncelleme : Guncel kelimeler www.pythontr.org adresine eklenecektir.

import os
import pygame
from pygame.locals import *
import sys
import random
import mp3_cal

pygame.init()
mp3_cal.mp3()
screen = pygame.display.set_mode((700, 600))
pygame.display.set_caption('sinif 1 el yazısı eğitim programı --- 2011')
screen.fill((225, 225, 225))

hand = pygame.font.match_font('Hand writing Mutlu')
font = pygame.font.Font(hand, 72)
hfile = open('kelimeler.txt')
word=hfile.readlines()
print 'Toplam kelime sayisi = ' + str(len(word))
hfile.close()

text = font.render('http://pythontr.org', True, (35, 35, 35), (225, 225, 225))

textRect = text.get_rect()
textRect.centerx = screen.get_rect().centerx
textRect.centery = screen.get_rect().centery
screen.blit(text, textRect)
pygame.display.update()
count = 0
exit = False
while not exit:
  for event in pygame.event.get():
      if event.type == QUIT:
          exit = True
      elif event.type == KEYDOWN:
          if event.key == K_ESCAPE:
              exit = True
      elif event.type == MOUSEBUTTONDOWN:
         font = pygame.font.Font(hand, 122)
         s=word[random.randrange(0, len(word))]
         s=s.replace('\n', '')
         text = font.render(s, True, (35, 35, 35), (225, 225, 225))

  screen.fill((225, 225, 225))
  textRect = text.get_rect()
  textRect.centerx = screen.get_rect().centerx
  textRect.centery = screen.get_rect().centery
  screen.blit(text, textRect)
  pygame.display.update()
pygame.quit()
