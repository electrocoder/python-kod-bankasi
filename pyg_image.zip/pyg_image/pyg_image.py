#------------------------------------------------------------------------------
#           Name: pyg_image.py
#         Author: Kevin Harris
#  Last Modified: 10/07/04
#    Description: This Python/Pygame script demonstrates how to load and 
#                 display an image file.
#------------------------------------------------------------------------------

import pygame
from pygame.locals import *

def main():
    pygame.init()	

    screen = pygame.display.set_mode( (640,480) )

    background = pygame.Surface( screen.get_size() )

    background.fill( (0,0,0) )

    image = pygame.image.load( "pygame_powered.bmp" )

    imagePosition = image.get_rect()

    imagePosition.bottom = 240
    imagePosition.left = 200

    screen.blit( background, (0,0) )
    screen.blit( image, imagePosition )

    pygame.display.flip()

    while 1:
        pygame.event.pump()
    
        keyinput = pygame.key.get_pressed()

        if keyinput[K_ESCAPE] or pygame.event.peek(QUIT):
            break

        screen.blit( background, (0,0) )
        screen.blit( image, imagePosition )

        pygame.display.flip()

if __name__ == '__main__': main()
