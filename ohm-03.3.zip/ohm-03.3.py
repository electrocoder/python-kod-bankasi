#!/usr/bin/python
# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ohm-03.ui'
#
# Created: Sun Jan 24 16:37:48 2010
#      by: PyQt4 UI code generator 4.7
#
# WARNING! All changes made in this file will be lost!

"""
Dosya Adi: ohm-03.py
Baslik: OHM kanunu hesaplayici
Yazan: Mehmet Yılmaz
E-posta: mehmet.yilmaz@teknomerkez.net
Tarih: 24.01.2010
-- Bu program Python 2.6.4 ile hazirlanmistir.
-- Kullanici arayuzu icin PyQt4 kullanilmistir.
"""

import sys
from PyQt4 import QtCore, QtGui

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(330, 225)
        self.centralwidget = QtGui.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.pushButton = QtGui.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(234, 180, 91, 23))
        self.pushButton.setObjectName("pushButton")
        self.pushButton_2 = QtGui.QPushButton(self.centralwidget)
        self.pushButton_2.setGeometry(QtCore.QRect(10, 180, 75, 23))
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_3 = QtGui.QPushButton(self.centralwidget)
        self.pushButton_3.setGeometry(QtCore.QRect(185, 70, 60, 23))
        self.pushButton_3.setObjectName("pushButton_3")
        self.pushButton_4 = QtGui.QPushButton(self.centralwidget)
        self.pushButton_4.setGeometry(QtCore.QRect(185, 100, 60, 23))
        self.pushButton_4.setObjectName("pushButton_4")
        self.pushButton_5 = QtGui.QPushButton(self.centralwidget)
        self.pushButton_5.setGeometry(QtCore.QRect(185, 130, 60, 23))
        self.pushButton_5.setObjectName("pushButton_5")
        self.line = QtGui.QFrame(self.centralwidget)
        self.line.setGeometry(QtCore.QRect(10, 160, 311, 16))
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName("line")
        self.textEdit = QtGui.QTextEdit(self.centralwidget)
        self.textEdit.setGeometry(QtCore.QRect(10, 10, 231, 51))
        self.textEdit.setObjectName("textEdit")
        self.pushButton_6 = QtGui.QPushButton(self.centralwidget)
        self.pushButton_6.setGeometry(QtCore.QRect(255, 10, 71, 23))
        self.pushButton_6.setObjectName("pushButton_6")
        self.pushButton_7 = QtGui.QPushButton(self.centralwidget)
        self.pushButton_7.setGeometry(QtCore.QRect(255, 40, 71, 23))
        self.pushButton_7.setObjectName("pushButton_7")
        self.pushButton_8 = QtGui.QPushButton(self.centralwidget)
        self.pushButton_8.setGeometry(QtCore.QRect(255, 70, 71, 23))
        self.pushButton_8.setObjectName("pushButton_8")
        self.lineEdit = QtGui.QLineEdit(self.centralwidget)
        self.lineEdit.setGeometry(QtCore.QRect(40, 70, 141, 20))
        self.lineEdit.setObjectName("lineEdit")
        self.lineEdit_2 = QtGui.QLineEdit(self.centralwidget)
        self.lineEdit_2.setGeometry(QtCore.QRect(40, 100, 141, 20))
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.lineEdit_3 = QtGui.QLineEdit(self.centralwidget)
        self.lineEdit_3.setGeometry(QtCore.QRect(40, 130, 141, 20))
        self.lineEdit_3.setObjectName("lineEdit_3")
        self.label = QtGui.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(10, 70, 31, 21))
        self.label.setObjectName("label")
        self.label_2 = QtGui.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(10, 100, 31, 21))
        self.label_2.setObjectName("label_2")
        self.label_3 = QtGui.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(10, 130, 31, 21))
        self.label_3.setObjectName("label_3")
        self.line_2 = QtGui.QFrame(self.centralwidget)
        self.line_2.setGeometry(QtCore.QRect(240, 10, 20, 151))
        self.line_2.setFrameShape(QtGui.QFrame.VLine)
        self.line_2.setFrameShadow(QtGui.QFrame.Sunken)
        self.line_2.setObjectName("line_2")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtGui.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 330, 20))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtGui.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        self.hesapla = hesapla(self)
        QtCore.QObject.connect(self.pushButton_6, QtCore.SIGNAL("clicked()"), self.hesapla.formuller)
        QtCore.QObject.connect(self.pushButton_7, QtCore.SIGNAL("clicked()"), self.hesapla.hakkinda)
        QtCore.QObject.connect(self.pushButton_8, QtCore.SIGNAL("clicked()"), self.hesapla.yardim)
        QtCore.QObject.connect(self.pushButton, QtCore.SIGNAL("clicked()"), MainWindow.close)
        QtCore.QObject.connect(self.pushButton_2, QtCore.SIGNAL("clicked()"), self.lineEdit_3.clear)
        QtCore.QObject.connect(self.pushButton_2, QtCore.SIGNAL("clicked()"), self.lineEdit_2.clear)
        QtCore.QObject.connect(self.pushButton_2, QtCore.SIGNAL("clicked()"), self.lineEdit.clear)
        QtCore.QObject.connect(self.pushButton_2, QtCore.SIGNAL("clicked()"), self.textEdit.clear)
        QtCore.QObject.connect(self.pushButton_3, QtCore.SIGNAL("clicked()"), self.hesapla.volthesapla)
        QtCore.QObject.connect(self.pushButton_4, QtCore.SIGNAL("clicked()"), self.hesapla.amperhesapla)
        QtCore.QObject.connect(self.pushButton_5, QtCore.SIGNAL("clicked()"), self.hesapla.ohmhesapla)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QtGui.QApplication.translate("MainWindow", "Ohm Kanunu Hesapları", None, QtGui.QApplication.UnicodeUTF8))
        self.pushButton.setText(QtGui.QApplication.translate("MainWindow", "Çıkış", None, QtGui.QApplication.UnicodeUTF8))
        self.pushButton_2.setText(QtGui.QApplication.translate("MainWindow", "Yeni", None, QtGui.QApplication.UnicodeUTF8))
        self.pushButton_3.setText(QtGui.QApplication.translate("MainWindow", "Volt Bul", None, QtGui.QApplication.UnicodeUTF8))
        self.pushButton_4.setText(QtGui.QApplication.translate("MainWindow", "Akım Bul", None, QtGui.QApplication.UnicodeUTF8))
        self.pushButton_5.setText(QtGui.QApplication.translate("MainWindow", "Ohm Bul", None, QtGui.QApplication.UnicodeUTF8))
        self.pushButton_6.setText(QtGui.QApplication.translate("MainWindow", "Formüller", None, QtGui.QApplication.UnicodeUTF8))
        self.pushButton_7.setText(QtGui.QApplication.translate("MainWindow", "Hakkında", None, QtGui.QApplication.UnicodeUTF8))
        self.pushButton_8.setText(QtGui.QApplication.translate("MainWindow", "Yardım", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("MainWindow", "Volt:", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("MainWindow", "Akım:", None, QtGui.QApplication.UnicodeUTF8))
        self.label_3.setText(QtGui.QApplication.translate("MainWindow", "Ohm:", None, QtGui.QApplication.UnicodeUTF8))

class hesapla:
    def __init__(self, mehmet):
        self.mehmet = mehmet
        mehmet.textEdit.setText(u"Bilinen değerleri giriniz ve bulunması istenen düğmeye tıklayınız")
    def hakkinda(self):
        mehmet.textEdit.setText(u"Mehmet Yılmaz\nmehmet.yilmaz@teknomerkez.net\nBu program GPL Lisanslıdır")
    def yardim(self):
        mehmet.textEdit.setText(u"Bilinen değerleri giriniz ve bulunması istenen düğmeye tıklayınız\nKüsüratlı değerleri nokta ile giriniz\nYardım için www.teknomerkez.net sitesine bakınız")
    def formuller(self):
        mehmet.textEdit.setText(u"Volt için: V=I*R\nAkım için: I=V/R\nOhm için: R=V/I")
    def ohmhesapla(self):
        if mehmet.lineEdit.text()=="" or mehmet.lineEdit_2.text()=="":
            mehmet.textEdit.setText(u"Bilinen değerler girilmelidir\nBoş bırakılan kutular var")
        else:
            try:
                mehmet.ohm = float(mehmet.lineEdit.text()) / float(mehmet.lineEdit_2.text())
                mehmet.lineEdit_3.setText(str(self.mehmet.ohm))
                mehmet.textEdit.setText(u"Direnç: "+str(self.mehmet.ohm)+u" Ohm\nVolt: "+str(mehmet.lineEdit.text())+u", Akım: "+str(mehmet.lineEdit_2.text()))
            except:
                mehmet.textEdit.setText(u"Hatalı giriş yaptınız\nSadece sayı giriniz")                
    def amperhesapla(self):
        if mehmet.lineEdit.text()=="" or mehmet.lineEdit_3.text()=="":
            mehmet.textEdit.setText(u"Bilinen değerler girilmelidir\nBoş bırakılan kutular var")
        else:
            try:
                mehmet.amper = float(mehmet.lineEdit.text()) / float(mehmet.lineEdit_3.text())
                mehmet.lineEdit_2.setText(str(self.mehmet.amper))
                mehmet.textEdit.setText(u"Akım: "+str(self.mehmet.amper)+u" Amper\nVolt: "+str(mehmet.lineEdit.text())+u", Ohm: "+str(mehmet.lineEdit_3.text()))
            except:
                mehmet.textEdit.setText(u"Hatalı giriş yaptınız\nSadece sayı giriniz")            
    def volthesapla(self):
        if mehmet.lineEdit_2.text()=="" or mehmet.lineEdit_3.text()=="":
            mehmet.textEdit.setText(u"Bilinen değerler girilmelidir\nBoş bırakılan kutular var")
        else:
            try:
                mehmet.volt = float(mehmet.lineEdit_2.text()) * float(mehmet.lineEdit_3.text())
                mehmet.lineEdit.setText(str(self.mehmet.volt))
                mehmet.textEdit.setText(u"Gerilim: "+str(self.mehmet.volt)+u" Volt\nAmper: "+str(mehmet.lineEdit_2.text())+u", Ohm: "+str(mehmet.lineEdit_3.text()))
            except:
                mehmet.textEdit.setText(u"Hatalı giriş yaptınız\nSadece sayı giriniz")
app = QtGui.QApplication(sys.argv)
window = QtGui.QMainWindow()
mehmet = Ui_MainWindow()
mehmet.setupUi(window)

window.show()
sys.exit(app.exec_())
