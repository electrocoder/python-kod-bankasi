#!/usr/bin/python
# -*- coding: cp1254 -*-

#####kullanimi#####
###exe'sini yapacaginiz programi bu programin bulundugu klasore koyup calistirin#
###birden fazla programi ayni anda exe'sine cevirebilir

from distutils.core import setup
import py2exe,sys
import os,shutil

def fonksiyon(pythonkodu):
    sys.argv.append("py2exe")
    setup(windows = [{"script": pythonkodu }])
         
A=[]
dizin=""
for i in os.listdir("%s"%(dizin)):
    a=len(i)
    if i=="exeyapici.py":
        continue
    if i[a-3:a]==".py" :
        A.append(i)

for i in A:
    a=len(i)
    try:
        os.mkdir("%s_dosyasi"%(i))
    except:
        continue
    
    fonksiyon(i)
    
    shutil.copytree("build","%s_dosyasi\\build"%(i),symlinks=False)
    shutil.copytree("dist","%s_dosyasi\\dist"%(i),symlinks=False)
    
    for j in os.listdir("%s_dosyasi\dist"%(i)):
        c=len(j)
        if j[-3]=="e":
            if j[0:c-4]<>i[0:a-3]:
                if j<>"w9xpopen.exe":
                    os.remove("%s_dosyasi\dist\%s "%(i,j))

try:                    
    shutil.rmtree("build",ignore_errors=False, onerror=None)
    shutil.rmtree("dist",ignore_errors=False, onerror=None)
except:
    pass


                    

