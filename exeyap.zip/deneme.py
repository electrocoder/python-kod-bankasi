# -*- coding: cp1254 -*-

import os

print "*** klasorde bulunan dosyalari listeler ***"
print os.listdir(os.getcwd())
