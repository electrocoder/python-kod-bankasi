#!/usr/bin/env python
#-*- coding: utf-8 -*-

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#Cımbız TCMB'den aldığı döviz bilgilerini kullanıcıya gösteren
#bir uygulamadır. Cımbız'ı kullanarak bugünün döviz kurlarını öğrenmenin 
#yanısıra eski tarihli döviz kurlarına da ulaşabilirsiniz.
#
#Copyright (C) 2009 - 2010 Firat Ozgul
#http://www.istihza.com
#
#Bu program bir özgür yazılımdır. Özgür Yazılım Vakfı'nca yayınlanan GNU Genel 
#Kamu Lisansı'nın 3. sürümü veya (tercihinize göre)  daha yeni sürümlerinin 
#hükümleri çerçevesinde bu yazılımı dağıtabilir ve/veya üzerinde değişiklik 
#yapabilirsiniz.
#
#Bu program faydalı olması ümidi ile dağıtılmakta, ancak HERHANGİ BİR GARANTİ 
#VERİLMEMEKTEDİR; hatta ORTALAMA KALİTE GARANTİSİ veya BELLİ BİR AMACA UYGUNLUK 
#iddiası dahi yoktur. Daha fazla ayrıntı için GNU Genel Kamu Lisansı'na bakınız.
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

import urllib
import datetime

class Backbone(object):
    def __init__(self):
        self.base = "http://www.tcmb.gov.tr/kurlar/"
    
    def receive_and_split(self, source):
        self.orig = source.decode("cp1254")
        self.uni = self.orig.encode("utf-8")
        
        self.split = self.uni.split()

        return self.split
    
    def find_match(self, curr, index):
        err = "Veri Yok"
        
        curr_dict = {"EURO" : index-1,
                     "SUUDİ": index+1}
        
        try:
            index = curr_dict[curr]
        except KeyError:
            pass
        
        try:
            self.match = self.split[self.split.index(curr)+index]
            return self.match
        
        except ValueError:
            return err

    def locate(self, mode, curr):
        mode_dict = {"doviz alis"   : 2, 
                     "doviz satis"  : 3,
                     "efektif alis" : 4,
                     "efektif satis": 5}
        
        location = mode_dict[mode]
        
        return self.find_match(curr, location)
        
    def get_today(self, mode, curr):
        self.today = urllib.urlopen("%s%s"%(self.base, "today.html")).read()

        self.receive_and_split(self.today)

        return self.locate(mode, curr)
    
    def get_archive(self, y, m, d, mode, curr):
        self.archive = urllib.urlopen("%s%s%s/%s%s%s.html"%(self.base, 
                                                            y, m, d, m, 
                                                            y)).read()

        self.receive_and_split(self.archive)

        return self.locate(mode, curr)
    
    def get_change(self, mode, curr):
        today = datetime.date.today()
        weekday = datetime.date.weekday(today)

        if weekday == 0: #pazartesi
            delta = datetime.timedelta(days = 3)
        elif weekday == 6: #pazar
            delta = datetime.timedelta(days = 2)
        else:
            delta = datetime.timedelta(days = 1)
        
        diff = today - delta
        year = diff.strftime("%Y")
        month = diff.strftime("%m")
        day = diff.strftime("%d")
        
        return self.get_archive(year, month, day, mode, curr)
    


