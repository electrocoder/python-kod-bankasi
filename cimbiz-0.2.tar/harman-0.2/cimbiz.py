#!/usr/bin/env python
#-*- coding: utf-8 -*-

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#Cımbız TCMB'den aldığı döviz bilgilerini kullanıcıya gösteren
#bir uygulamadır. Cımbız'ı kullanarak bugünün döviz kurlarını öğrenmenin 
#yanısıra eski tarihli döviz kurlarına da ulaşabilirsiniz.
#
#Copyright (C) 2009 - 2010 Firat Ozgul
#http://www.istihza.com
#
#Bu program bir özgür yazılımdır. Özgür Yazılım Vakfı'nca yayınlanan GNU Genel 
#Kamu Lisansı'nın 3. sürümü veya (tercihinize göre)  daha yeni sürümlerinin 
#hükümleri çerçevesinde bu yazılımı dağıtabilir ve/veya üzerinde değişiklik 
#yapabilirsiniz.
#
#Bu program faydalı olması ümidi ile dağıtılmakta, ancak HERHANGİ BİR GARANTİ 
#VERİLMEMEKTEDİR; hatta ORTALAMA KALİTE GARANTİSİ veya BELLİ BİR AMACA UYGUNLUK 
#iddiası dahi yoktur. Daha fazla ayrıntı için GNU Genel Kamu Lisansı'na bakınız.
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

import pygtk
import gtk
pygtk.require20()
import backbone
import webbrowser
import os
import datetime
import globius as gl

class Cimbiz(object):
    def __init__(self):
        #Windows'ta temayı ayarlıyoruz...
        if os.name == "nt":
            theme_file = open("themes/human")
            style = gtk.rc_parse_string(theme_file.read())
        
        #ana penceremiz...
        self.root = gtk.Window(gtk.WINDOW_TOPLEVEL)
        self.root.set_position(gtk.WIN_POS_CENTER)
        self.root.set_title("CIMBIZ")
        self.root.set_border_width(30)
        self.root.connect("delete_event", gtk.main_quit)

        #desteklenen para birimlerinin listesi
        self.cur_list = ["ABD Doları", 
                         "AVUSTRALYA Doları", 
                         "DANİMARKA Kronu",
                         "EURO", 
                         "İNGİLİZ Sterlini", 
                         "İSVİÇRE Frangı",
                         "İSVEÇ Kronu", 
                         "KANADA Doları", 
                         "KUVEYT Dinarı",
                         "NORVEÇ Kronu", 
                         "SUUDİ ARABİSTAN Riyali", 
                         "JAPON Yeni (100)"]
                         
        #2003'ten günümüze kadar olan tarihleri 
        #gün, ay ve yıl olarak tutan liste.
        #Bu tarihler arayüzün sağındaki combobox
        #aracında yer alacak.
        self.date = [
                     [str(i).zfill(2) for i in range(1, 32)], #gün
                     [str(i).zfill(2) for i in range(1, 13)], #ay
                     [str(i) for i in range(2003, 2011)]      #yıl
                    ]

        #pencere araçlarını oluşturuyoruz...
        self.create_widgets()
    
    def create_widgets(self):
        #ana pencere aracı taşıyıcıları
        self.main_vbox = gtk.VBox()
        self.root.add(self.main_vbox)
        
        self.main_hbox = gtk.HBox()
        self.main_vbox.pack_start(self.main_hbox, False, False, 10)

        #dövizleri tutan combobox
        cur_combo = self.create_combobox(self.cur_list, self.main_hbox)

        #seçilen para biriminin ait olduğu ülkenin bayrağını gösteriyoruz
        cur_combo.connect("changed", self.change_flag)
        
        #bugünkü kurları alan düğme
        self.t_btn = self.create_button(\
        u"Bugünkü Kur", self.main_hbox, 
        lambda x: self.show_today(cur_combo.get_active_text().split()[0]))
        
        self.t_btn.set_tooltip_text("TCMB, hafta içi her gün saat 15:30'da "
        "döviz kurlarını günceller.")
        
        #dikey ayraç
        self.vsep = self.create_separator("vertical", self.main_hbox)
        
        #tarih bilgilerini tutan combobox
        self.combo_dict = {}
        
        cnt = 0
        
        while cnt < 3:
            for dt, tt in [("day", "gün"), ("month", "ay"), ("year", "yıl")]:
                self.combo_dict[dt] = self.create_combobox(self.date[cnt], 
                                                           self.main_hbox)
                self.combo_dict[dt].set_tooltip_text(tt)
                cnt += 1
        
        #geçmiş kurları alan düğme
        self.a_btn = self.create_button(\
        u"Geçmiş Kur", self.main_hbox, 
        lambda x: self.show_archive(cur_combo.get_active_text().split()[0]))
        
        self.a_btn.set_tooltip_text("Seçtiğiniz tarih resmi bayramlara "
        "veya haftasonuna denk geliyorsa, 'Veri Yok' uyarısı görüntülenir.")
        #bayrakları ve okları bu taşıyıcı tutacak
        self.image_hbox = gtk.HBox(True, 10)
        
        #öntanımlı bayrak ABD bayrağı
        self.flag = gtk.Image()
        self.flag.set_from_file("%s%s"%(gl.resimdizini, gl.resimler["ABD Doları"]))
        self.image_hbox.pack_start(self.flag)
        
        #kur değişimini gösteren ok simgesi
        self.arrow = gtk.Image()
        self.show_im()
        self.image_hbox.pack_start(self.arrow)
        
        #bayrak ve ok simgesini sola yaslıyoruz
        self.align = gtk.Alignment(0, 0, 0, 0)
        self.main_vbox.pack_start(self.align, False, False, 15)

        self.align.add(self.image_hbox)
        
        #döviz bilgilerini göstereceğimiz alanı bir çerçeve içine alalım
        self.frame = gtk.Frame()
        self.frame.set_size_request(90, 130)
        self.frame.set_shadow_type(gtk.SHADOW_IN)
        self.frame.modify_bg(gtk.STATE_NORMAL, gtk.gdk.color_parse("gray"))
        self.main_vbox.pack_start(self.frame)
        
        #döviz bilgilerini göstereceğimiz alanı oluşturuyoruz
        self.table = self.create_table(3, 3, self.frame)
        
        #tablo başlıkları
        col_headers = ["Döviz Alış", "Döviz Satış", 
                       "Efektif Alış", "Efektif Satış"]
        
        row_s = 0
        row_e = 1
        
        while row_s < 3 and row_e < 4:
            for col_header in col_headers:
                self.create_label(col_header, row_s, row_e , 0, 1, self.table)
                row_s += 1
                row_e += 1
        
        #döviz bilgilerini gösteren etiketler
        self.cbuy = gtk.Label()
        self.csell = gtk.Label()
        self.ebuy = gtk.Label()
        self.esell = gtk.Label()
        
        #döviz etiketleri ve bunları görevleri arasındaki ilişkiyi
        #gösteren liste
        self.mapping = [
                        (self.cbuy,  "doviz alis"),
                        (self.csell, "doviz satis"),
                        (self.ebuy,  "efektif alis"),
                        (self.esell, "efektif satis")
                       ]
        
        r = 0
        c = 1
        
        while r < 3 and c < 4:
            for lbl in [self.cbuy, self.csell, self.ebuy, self.esell]:
                lbl.set_selectable(True)
                self.table.attach(lbl, r, c, 1, 2)
                r += 1
                c += 1

        #temizle, kapat, hakkında...
        self.hbut = gtk.HButtonBox()
        self.hbut.set_layout(gtk.BUTTONBOX_END)
        self.main_vbox.pack_start(self.hbut, False, False, 20)
        
        self.create_button("Temizle", self.hbut, self.clear)
        self.create_button("Kapat", self.hbut, gtk.main_quit)
        self.create_button("Hakkında", self.hbut, self.about_box)
        
        self.root.show_all()
    
    def visit_website(self, penar):
        webbrowser.open(gl.url)
    
    def create_separator(self, type, container):
        if type == "vertical":
            sep = gtk.VSeparator()
        
        elif type == "horizontal":
            sep = gtk.HSeparator()
        
        container.pack_start(sep, False, False, 35)
        
        return sep
   
    def create_table(self, row, column, container):
        tbl = gtk.Table(row, column, True)
        tbl.set_row_spacings(10)
        container.add(tbl)
        
        return tbl
    
    def create_label(self, text, row_start, row_end, col_start, col_end, container):
        self.lbl = gtk.Label(text)
        self.lbl.set_alignment(0.5, 0.0)
        self.lbl.set_markup("<b><u>%s</u></b>"%self.lbl.get_label())
        self.lbl.set_markup(\
        "<span foreground='black' font='13'>%s</span>"%self.lbl.get_label())
        container.attach(self.lbl, row_start, row_end, col_start, col_end)
    
    def create_button(self, text, container, command=None):
        btn = gtk.Button(text)
        btn.connect("clicked", command)
        container.pack_start(btn, False, False)
        
        return btn
    
    def create_combobox(self, items, container):
        combo = gtk.combo_box_new_text()
        combo.set_active(1)
        for item in items:
            combo.append_text(item)
        
        combo.set_active(0)
        
        container.pack_start(combo, False, False)
        
        return combo

    def change_flag(self, penar):
        self.clear()
        self.hide_im()
        self.flag.set_from_file("%s%s"%(gl.resimdizini, 
                                        gl.resimler[penar.get_active_text()]))
    
    def show_today(self, currency):
        bb = backbone.Backbone()

        self.pml = "<span foreground='navy' font='12'>%s</span>\
            <span foreground='#7F7F7F' font='12'>%s</span>"
        
        for i in [self.cbuy, self.csell, self.ebuy, self.esell]:
            i.set_alignment(0.5, 0.5)                            
            i.set_text("alınıyor...")

        while gtk.events_pending():
            gtk.main_iteration()
        
        for k, v in self.mapping:
            k.set_text(bb.get_today(v, currency)+"\n"+bb.get_change(v, currency))
            k.set_alignment(1.0, 0.5)
        
        for t in [self.cbuy, self.csell, self.ebuy, self.esell]:
            t.set_markup(self.pml %(t.get_label()[:len(t.get_label())/2], 
                                    t.get_label()[len(t.get_label())/2:]))
            t.set_tooltip_text("İlk sıradaki sayılar bugünkü, ikinci sıradaki "
            "sayılar ise bir gün önceki kuru gösterir. TCMB o güne ait kur "
            "bilgilerini henüz güncellememişse, eski ve yeni değerler "
            "birbiriyle aynı olacaktır.")
        
        self.show_diff(currency)
        self.show_im()

    def show_archive(self, currency):
        self.hide_im()
        bb = backbone.Backbone()

        for i in [self.cbuy, self.csell, self.ebuy, self.esell]: 
            i.set_alignment(0.5, 0.5)                            
            i.set_text("alınıyor...")

        while gtk.events_pending():
            gtk.main_iteration()
                   
        for k, v in self.mapping:
            k.set_alignment(0.5, 0.5)
            k.set_text(bb.get_archive(self.combo_dict["year"].get_active_text(),
                                      self.combo_dict["month"].get_active_text(), 
                                      self.combo_dict["day"].get_active_text(),
                                      v, currency))
                                      
            k.set_markup("<span foreground='navy' font='12'>%s</span>"%k.get_label())
        
    def about_box(self, penar):
        about = gtk.AboutDialog()
        about.set_logo(gtk.gdk.pixbuf_new_from_file(\
        "%s%s"%(gl.resimdizini, gl.resimler["cimbiz"])))
        about.set_name(gl.ad.upper())
        about.set_comments(gl.aciklama)
        about.set_license(gl.lisans)
        about.set_wrap_license(True)
        about.set_copyright(u"Copyright (C) 2009-%s %s"\
        %(datetime.date.today().strftime("%Y"), gl.yazar))
        about.set_website(gl.url)
        about.set_authors([gl.yazar])
        about.set_documenters([gl.belgelendirici])
        about.set_version(gl.versiyon)
        about.run()
        about.destroy()
        
    def clear(self, penar=None):
        self.hide_im()
        
        for lbl in [self.cbuy, self.csell, self.ebuy, self.esell]:
            lbl.set_text(" ")
    
    def hide_im(self):
        self.arrow.hide()
    
    def show_im(self):
        self.arrow.show()
    
    def show_diff(self, curr):
        bb = backbone.Backbone()

        self.current_value = bb.get_today("doviz alis", curr)
        self.old_value = bb.get_change("doviz alis", curr)
        
        if self.current_value == self.old_value:
            sign = "noc"

        elif self.current_value < self.old_value:
            sign = "down"

        else:
            sign = "up"

        self.arrow.set_from_file("%s%s"%(gl.resimdizini, gl.resimler[sign]))
           
    def main(self):
        gtk.main()

cmb = Cimbiz()
cmb.main()
        
