#!/usr/bin/env python
#-*- coding: utf-8 -*-

import os 
import locale
import sys
import datetime
#roundceiling hatası almak istemiyoruz...
locale.setlocale(locale.LC_ALL, 'C')

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#programımızın adı
ad = 'CIMBIZ'

#programımızın versiyonu
versiyon = 'v0.2'

#programımızın yazarı
yazar = u'Fırat Özgül (istihza)'

#programımızın belgelendiricisi
belgelendirici = u'Fırat Özgül (istihza)'

#programımızın internet adresi
url = 'http://www.istihza.com'

#yazarın e.posta adresi
eposta = 'kistihza@yahoo.com'

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#Programda kullanılan resimler
resimler = {'up'                    : 'cik.png',
            'down'                  : 'dus.png',
            'noc'                   : 'noc.png',
            'ABD Doları'            : 'abd.png',
            'AVUSTRALYA Doları'     : 'avustralya.png',
            'KANADA Doları'         : 'kanada.png',
            'DANİMARKA Kronu'       : 'danimarka.png',
            'EURO'                  : 'euro.png',
            'İNGİLİZ Sterlini'      : 'ingiliz.png',
            'İSVEÇ Kronu'           : 'isveç.png',
            'İSVİÇRE Frangı'        : 'isviçre.png',
            'JAPON Yeni (100)'      : 'japon.png',
            'KUVEYT Dinarı'         : 'kuveyt.png',
            'NORVEÇ Kronu'          : 'norveç.png',
            'SUUDİ ARABİSTAN Riyali': 'suudi.png',
            'cimbiz'                : 'cimbiz.png'
            }

#Programda kullanılan belgeler
belgeler = {}

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#Varsayılan kurulum dizini
pkurdiz = '/usr/share/%s'%ad.lower() + os.sep #paketse
kkurdiz = os.getcwd() #kaynaksa

#Varsayılan resim ve belge dizinleri
presdiz = '%sresimler'%pkurdiz + os.sep #paketse
pbeldiz = '%sbelgeler'%pkurdiz + os.sep #paketse

kresdiz = os.path.join(kkurdiz, 'resimler') + os.sep #kaynaksa
kbeldiz = os.path.join(kkurdiz, 'belgeler') + os.sep #kaynaksa

#Varsayılan simge dizini
pikondiz = '/usr/share/pixmaps' + os.sep

#Varsayılan desktop dosyası dizini
pdeskdiz = '/usr/share/applications' + os.sep

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#Eğer HARMAN GNU/Linux altında paketten çalıştırılıyorsa...
if os.path.dirname(sys.argv[0]) == pkurdiz[:-1] and os.name == 'posix':
    resimdizini = presdiz
    belgedizini = pbeldiz
#Windows...
else:
    resimdizini = kresdiz
    belgedizini = kbeldiz
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#

#programımızın kısa tanımı
tanim = 'CIMBIZ, TCMB döviz kurlarını gösteren bir uygulamadır.'

#programımızın uzun açıklaması
aciklama = '''Cımbız TCMB'den aldığı döviz bilgilerini kullanıcıya gösteren bir \
uygulamadır. Cımbız'ı kullanarak bugünün döviz kurlarını öğrenmenin yanısıra eski \
tarihli döviz kurlarına da ulaşabilirsiniz.'''

#programımızın lisansının adı
lisans_adi = 'GPL v3'

#programımızın kısa lisans tanımı
lisans = '''%s

Copyright (C) 2009 - %s Firat Ozgul

Bu program bir özgür yazılımdır. Özgür Yazılım Vakfı'nca yayınlanan GNU Genel \
Kamu Lisansı'nın 3. sürümü veya (tercihinize göre) daha yeni sürümlerinin hükümleri \
çerçevesinde bu yazılımı dağıtabilir ve/veya üzerinde değişiklik yapabilirsiniz.

Bu program faydalı olması ümidi ile dağıtılmakta, ancak HERHANGİ BİR GARANTİ \
VERİLMEMEKTEDİR; hatta ORTALAMA KALİTE GARANTİSİ veya BELLİ BİR AMACA UYGUNLUK \
iddiası dahi yoktur. Daha fazla ayrıntı için GNU Genel Kamu Lisansı'na bakınız.'''\
%(tanim, datetime.date.today().strftime("%Y"))

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#Cımbız'ın tek bağımlılığı pygtk modülüdür.
pygtk_url = 'http://www.istihza.com/gtk/temel_bilgiler.html'

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#İşimizi kolaylaştırmak ve sağlama almak için bazı fonksiyonlar
#tanımlamamız gerekiyor...
def check_user(usage):
    '''Kullanıcının sistemde root olup olmadığını kontrol eder ve
    kullanıcı bilgisini döndürür...'''
    user = os.getuid()
    if user != 0:
        print u'\nBu betik yalnızca root haklarıyla çalıştırılabilir.\nKullanımı: %s\n'%usage
        sys.exit()
    
    return user

def check_argv(module, usage):
    '''sys.argv'deki seçenekler arasında kurulum bilgilerini içeren 
    dosyanın olup olmadığını kontrol eder...'''
    if len(sys.argv) < 2:
        print u'\nKurulum dizinlerinin adını içeren dosyayı %s betiğine argüman '
        'olarak vermelisiniz.\n'%module
        print u'Kullanım: %s\n'%usage
        sys.exit()

def add_option_to_argv(option, installation_text):
    '''option argümanını installation_text'i de içerecek şekilde 
    sys.argv'ye ekler...'''
    if "install" in sys.argv and option not in sys.argv:
        sys.argv.extend([option, installation_text])

def missing_module_warning(module, module_url):
    '''eksik modüller konusunda kullanıcıyı uyarır...'''
    print u'\nSisteminizde %s modülü yok. Lütfen CIMBIZ\'ı çalıştırmadan önce '
    'bu modülü kurunuz. Bu modülü nasıl kuracağınızı öğrenmek için %s adresini '
    'ziyaret edin.'%(module, module_url)
