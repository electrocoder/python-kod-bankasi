#!/usr/bin/env python
# -*- coding: utf-8 -*-
#Muslu YÜKSEKTEPE 2009
#musluyuksektepe@gmail.com
#www.djangoturkiye.com
#www.yazki.com
#AutoDjango script v0.58
#Ubuntu işletim sistemi için hazırlanmıştır.



from __future__ import division
import os, time
import zipfile
klasoryolu = os.path.dirname(__file__)
dosyayolu = os.path.join(klasoryolu, '')
zip_dosyasi = zipfile.ZipFile(dosyayolu + "yeniproje.zip")
kullaniciadiogren = os.getenv("LOGNAME").replace("LOGNAME=", "")
klasorolustur = ("/home/" + kullaniciadiogren)

try:
    import django
except ImportError:
    os.system('clear')
    print "Bu script Muslu YÜKSEKTEPE tarafindan hazirlanmistir.\n"
    print "Django yuklu degil!\nOncelikle Django icin gerekli kutuphaneler yuklenecek.\n--Python, Apache2, Mysql, Django --"
    print "Gerekli tum kutuphanelerin yuklenmesi 5 saniye sonra  otomatik olarak baslatilacaktir.!\nLutfen internet baglantinizi kontrol ediniz"
    print "Lutfen yukleme islemleri bittikten sonra scripti tekrar calistiriniz"
    os.system('sudo chmod +x kullaniciolustur.py')
    time.sleep(5)
    os.system('sudo apt-get -y install mysql-server-5.1 python-mysqldb subversion python-django python-textile python-markdown python-imaging apache2 apache2-mpm-prefork libapache2-mod-auth-mysql libapache2-mod-python libapache2-mod-ldap-userdir  language-pack-tr')
    os.system('./kullaniciolustur.py')
else:
    while True:
        os.system('clear')
        print "Bu script Muslu YÜKSEKTEPE tarafindan hazirlanmistir.\n"
        print "Merhaba: " + kullaniciadiogren + " \nBu kurulum dosyalari sayesinde otomatik olarak hazir Django projesi olusturulacaktir. \nLutfen bilgileriniz kontrol ederek yaziniz.\n"
        kullaniciadi = raw_input("Olusturulacak proje adi (orn:yazkicom)  :")
        domainadi = raw_input("Olusturulacak domain adi (orn:www.yazki.com) :")
######################################################################################################
        if not kullaniciadi == "" : 
######################################################################################################
                os.system('mkdir ' + klasorolustur + "/django/")
#                os.system('cd ' + klasorolustur)
                os.system('mkdir ' + klasorolustur + "/django/"+ kullaniciadi)
                print "\n\nKlasor olusturuldu!\n"
######################################################################################################
                zip_dosyasi.extractall("/home/"+ kullaniciadiogren + "/django/" + kullaniciadi)
                print "Zip dosyasi acildi!\n"
######################################################################################################
                try:
                    import MySQLdb
                except ImportError:
                    print "MySQLdb modulu yuklu degil!\n"
                    print "MySQLdb modulu yuklenmesi 5 saniye sonra otomatik olarak baslatilacaktir.!\nLutfen internet baglantinizi kontrol ediniz\nİslem tamamlandiktan sonra bu programi tekrar calistiriniz"
                    time.sleep(5)
                    os.system('sudo apt-get install mysql-client-5.1 python-mysqldb')
                else:
                    mysqlkullaniciadi = raw_input("MYSQL ROOT kullanicisi:")
                    mysqlparola = raw_input("MYSQL ROOT parolasi:")
                    olusturmysqlkullaniciadi = raw_input("Proje icin MYSQL kullanici adini yazin:")
                    olusturmysqlparola = raw_input("Proje icin MYSQL Parolaniz:")
                    db=MySQLdb.connect(host="localhost", user=mysqlkullaniciadi, passwd=mysqlparola)
                    c=db.cursor()
                    c.execute('create database ' + kullaniciadi +  ' charset=utf8;')
                    c.execute('GRANT ALL ON ' + kullaniciadi + '.* TO '+olusturmysqlkullaniciadi+'@localhost IDENTIFIED BY "'+olusturmysqlparola+'";')
                    print "\n\nMysql veritabani olusturuldu!\n"
######################################################################################################
##/usr/lib/pymodules/python2.6/django
                os.system('sudo chmod a+rw /etc/apache2/sites-enabled/')
                apachedosyaolustur = open("/etc/apache2/sites-enabled/" + domainadi + ".conf", "w")
                apachedosyaolustur.write ("NameVirtualHost *\n")
                apachedosyaolustur.write ("<VirtualHost *>\n")
                apachedosyaolustur.write ("ServerAdmin musluyuksektepe@gmail.com\n")
                apachedosyaolustur.write ("ServerName " + domainadi + "\n")
                apachedosyaolustur.write ("DocumentRoot " + "/home/"+  kullaniciadiogren + "/django/" + kullaniciadi + "\n")
                apachedosyaolustur.write ("ErrorLog /var/log/apache2/" + kullaniciadi + "_error.log\n")
                apachedosyaolustur.write ("LogLevel warn\n")
                apachedosyaolustur.write ("CustomLog /var/log/apache2/apache.log combined\n")
                apachedosyaolustur.write ("Alias /media "+'"'+"/usr/lib/pymodules/python2.6/django/contrib/admin/media"+'"'+"\n")
                apachedosyaolustur.write ("Alias /static "+'"' +"/home/"+  kullaniciadiogren + "/django/" + kullaniciadi + "/static"+'"'+"\n")
                apachedosyaolustur.write ("\n")
                apachedosyaolustur.write ("<Location  "+'"'+"/"+'"'+">\n")
                apachedosyaolustur.write ("        SetHandler mod_python\n")
                apachedosyaolustur.write ("        PythonHandler django.core.handlers.modpython\n")
                apachedosyaolustur.write ("        SetEnv DJANGO_SETTINGS_MODULE " + kullaniciadi + ".settings\n")
                apachedosyaolustur.write ("        PythonInterpreter "+ kullaniciadi + "\n")
                apachedosyaolustur.write ("        PythonOption django.root /" + kullaniciadi + "\n")
                apachedosyaolustur.write ("        PythonDebug On\n")
                apachedosyaolustur.write ("        PythonPath "+'"'+"['" + "/home/"+  kullaniciadiogren + "/django/" + "'] + sys.path"+'"'+"\n")
                apachedosyaolustur.write ("</Location>\n")
                apachedosyaolustur.write ("\n")
                apachedosyaolustur.write ("<Location "+'"'+"/static/"+'"'+">\n")
                apachedosyaolustur.write ("        SetHandler None\n")
                apachedosyaolustur.write ("</Location>\n")
                apachedosyaolustur.write ("\n")
                apachedosyaolustur.write ("<Location "+'"'+"/media/"+'"'+">\n")
                apachedosyaolustur.write ("        SetHandler None\n")
                apachedosyaolustur.write ("</Location>\n")
                apachedosyaolustur.write ("</VirtualHost>\n")
                apachedosyaolustur.close()
                print "Apache2 icin conf dosyasi olusturuldu!"
######################################################################################################
                settingspy = ("/home/" + kullaniciadiogren + "/django/" + kullaniciadi + "/" + "settings.py")
                settingspyduzenle = open(settingspy, "a")
                settingspyduzenle.write ("ROOT_URLCONF = '" + kullaniciadi + ".urls'\n")
                settingspyduzenle.write ("DATABASE_ENGINE = 'mysql'\n")
                settingspyduzenle.write ("DATABASE_NAME = '" + kullaniciadi + "'\n")
                settingspyduzenle.write ("DATABASE_USER = '" +olusturmysqlkullaniciadi+"'\n")
                settingspyduzenle.write ("DATABASE_PASSWORD = '" +olusturmysqlparola+"'\n")
                indexhtm = ("/home/" + kullaniciadiogren + "/django/" + kullaniciadi + "/templates/" + "index.html")
                indexhtmduzenle = open(indexhtm, "a")
                indexhtmduzenle.write ("<p>Kurulum tamamlandı! " +domainadi+ " </p>")
                indexhtmduzenle.write ("</body> </html>")
                indexhtmduzenle.close()
                os.system('clear')
                print ("Projenin settings.py dosyasi duzenlendi!\n")
                yoloku = ("/home/" + kullaniciadiogren + "/django/" +kullaniciadi + "/")
                print ("cd " + yoloku)
                print ("python manage.py syncdb \n")
                print ("yazarak projenizin veritabanını olusturabilirsiniz.")     
######################################################################################################
# apache2 yi otomatik restart ettirmek için alt satırı aktif edin.
#      	       os.system ('sudo /etc/init.d/apache2 restart')
######################################################################################################
                print "Tum islemler basariyla tamamlandi!\n\n"
                print "Muslu Yuksektepe      www.yazki.com      musluyuksektepe@gmail.com"
                break 
        else: 
                print "Kullanici adi bos gecilemez!!!\n\nTekrar deneyiniz.\n" 

