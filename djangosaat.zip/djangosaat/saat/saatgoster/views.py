from datetime import datetime
from django.shortcuts import render_to_response

def AnaSayfadaGoster(request):
   saat = datetime.now()
   
   return render_to_response('index.html',
                                  {'saat' : saat }
                             )
